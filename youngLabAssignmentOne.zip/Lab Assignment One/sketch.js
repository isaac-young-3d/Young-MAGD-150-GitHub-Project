/*
Isaac J. Young
Intro to MAGD
Lab Assignment One

This program will create a 'Cityscape' scene
There will be a 128x128 canvas
The canvas will have a grey background
All shapes will be made using primitive types
One of these primitive shapes will use noStroke
Atleast one shape will have a bevel
*/

function setup() {
  // put setup code here
    createCanvas(128, 128);

}

function draw() {
  // put drawing code here
    background(100);
    moonStars();
    firstRow();
    secondRow();

}

function moonStars(){
    //Draws the moon and stars in the city
    stroke(200);
    strokeWeight(20);
    point(100,20);
    strokeWeight(2);
    point(10,10);
    stroke(250);
    point(30,10);
    stroke(180);
    point(15,20);
    point(5,30);
    point(39,30);
    point(50,10);
    point(35,25);
    point(20,45);
    point(43,10);
    stroke(250);
    point(50,34);
    point(58,70);
    stroke(210);
    point(60,20);
    point(65,35);
    point(68,80);
    stroke(250);
    point(60,55);
    stroke(200);
    point(75,8);
    point(80,20);
    point(83,35);
    point(75,40);
    stroke(180);
    point(90,40);
    point(80,50);
    point(100,55);
    stroke(200);
    point(95,40);
    point(110,35);
    point(105,60);

}

function firstRow(){
    //Draws the first row of buildings in the city
    fill(85);
    stroke(0);
    strokeJoin(BEVEL);
    strokeWeight(1);
    rect(0, 78, 20, 50);
    fill(95);
    rect(40, 108, 40, 20);
    strokeWeight(3);
    rect(100, 78, 20, 50);
}

function secondRow(){
    //Draws the second row of buildings in the city
    fill(120);
    noStroke();
    rect(15, 58, 30, 70);
    fill(130);
    rect(75, 68, 20, 60);
}