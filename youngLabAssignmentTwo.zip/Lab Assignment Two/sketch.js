/*
Isaac J. Young
Intro to MAGD
Lab Assignment Two

This program will draw a balloons scene
The canvas will be 128x128
The background will be grayscale
There will be atleast 4 colors represented in the scene
These colors will use the RGBA color mode
There will be triangles, curves, and arcs
*/

function setup() {
  // put setup code here
    createCanvas(128, 128);

}

function draw() {
    // put drawing code here
    colorMode(RGB, 255, 255, 255, 1);
    background(100);

    noFill();
    stroke(255);
    curve(50, 50, 55, 55, 60, 100, 50, 100);
    curve(60, 60, 65, 65, 70, 110, 60, 110);
    curve(70, 50, 75, 55, 80, 100, 70, 100);
    curve(80, 60, 85, 65, 90, 110, 80, 110);
    curve(40, 60, 45, 65, 50, 110, 40, 110);

    stroke(255, 100, 20);
    fill(200, 10, 10);
    arc(50, 50, 15, 20, 0, 2 * PI);
    triangle(55, 55, 50, 60, 60, 60);
    fill(200, 200, 30);
    arc(60, 60, 15, 20, 0, 2 * PI);
    triangle(65, 65, 60, 70, 70, 70);
    fill(10, 200, 10);
    arc(70, 50, 15, 20, 0, 2 * PI);
    triangle(75, 55, 70, 60, 80, 60);
    fill(10, 10, 200);
    arc(80, 60, 15, 20, 0, 2 * PI);
    triangle(85, 65, 80, 70, 90, 70);
    arc(40, 60, 15, 20, 0, 2 * PI);
    triangle(45, 65, 40, 70, 50, 70);

}