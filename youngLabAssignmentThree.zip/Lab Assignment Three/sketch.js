/*
Isaac J. Young
Intro to MAGD
Lab Assignment Three

This program will track the mouse and draw where it is
There will be a 400 x 400 canvas
The background will be grayscale
The colormode will be RGB with atleast 3 different colors
There will be atleast 3 variables used in this program
frameRate() will be incorporated in the setup
The mouse position will be tracked in the program
This program will use the math functions pow() and dist()
*/

//Initializing variables
let fr = 0;
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let d = 0;

function setup() {
  // put setup code here
    let fr = 30;

    createCanvas(1000, 1000);
    frameRate(fr);

    background(250);
    colorMode(RGB, 255, 255, 255, 1);

    fill(255, 0, 0);
    rect(100, 100, 200, 200);
    fill(0, 0, 255);
    rect(200, 200, 300, 300);

}

function draw() {
    // put drawing code here
    let mx = mouseX;
    let my = mouseY;
    let px = pmouseX;
    let py = pmouseY;
    let d = dist(mx, my, px, py);

    stroke(0, 255, 0);
    fill(0);

   
    line(mx, my, px, py);
    strokeWeight(pow(d / 2, 2));
    

}